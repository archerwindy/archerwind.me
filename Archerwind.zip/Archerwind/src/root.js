import './sass/style.scss';
import React from 'react';
import { render } from 'react-dom';
import Routes from './script/router/routes';


render( Routes, document.getElementById('main'));
