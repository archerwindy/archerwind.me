import constants from 'react-constants';

export const global = constants([
  'LANGUAGE_PACKAGE_SWITCH',
  'GET_JSON_LANGUAGE_PACKAGE'
])

