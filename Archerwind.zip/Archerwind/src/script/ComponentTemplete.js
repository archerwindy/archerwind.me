
/* Component templete */

import React , { Component } from 'react';
export default class ComponentName extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  componentWillMount() {}
  componentDidMount() {}
  render() {
    return (<div/>);
  }
}
