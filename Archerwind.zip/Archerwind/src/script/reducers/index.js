import { combineReducers } from 'redux';

// Reducers
import global from './global';

export default combineReducers({
  global
});
