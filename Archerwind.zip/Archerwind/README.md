# Giftpack F2E Generator


<img src="https://github.com/VANITAX/Front-end-Redux-React-Generator/blob/master/cover.png?raw=true"/>

### Initialize

    npm install
    
### Start 

    npm start 
    
### Publish

    npm run publish
    
### JS Lint

    npm run lint
